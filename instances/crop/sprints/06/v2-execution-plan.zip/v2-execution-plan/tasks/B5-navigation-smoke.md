# B5 — Navigation smoke (B1 + B2 sign-off)

- **Epic:** B · **Owner:** Denis (you) · **Day:** D3 · **Repo:** CROP-front
- **Depends on:** B1 + B2 PRs submitted

## Impact
B1 (desktop loop) and B2 (mobile parity) are the two highest-visibility UX fixes in the demo.
QA sign-off here is what lets Vova merge them with confidence.

## Desktop circular-loop check (B1) — Chrome 1280px
1. `/parts-diagrams/ferris`
2. Click a model card → click an assembly
3. Click **every** link on the assembly page (breadcrumbs, any back button, brand link)
4. ✅ "Ferris" crumb → `/parts-diagrams/ferris` (not `/parts-diagrams` root)
5. ✅ No single click returns you to the page you were already on
6. Repeat for Ventrac + McHale; confirm New Holland path unchanged
7. Also re-walk the brand-landing "Open parts diagram" CTA (the click John demoed)

## Mobile drawer check (B2) — DevTools iPhone SE (375×667)
1. Any assembly page: `/parts-diagrams/ferris/{modelCode}/assemblies/{assemblyCode}`
2. ✅ "Browse Diagrams" trigger visible without scrolling
3. Tap → ✅ drawer opens with **images** (not just text)
4. Tap an image → ✅ schematic shows that section; drawer closed
5. Pinch-zoom the schematic → ✅ still works (not frozen)
6. Tap outside → ✅ closes cleanly; schematic still pannable

## Output
Comment on each PR: `Local test: PASS — verified at 375px and 1280px` or
`Local test: FAIL — <specific thing + repro>`. Denis's PASS is the signal for Vova's final
review. Any FAIL → file with impact statement, assign Oleg.
