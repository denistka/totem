# C3 — Brief Dan on multibrand search

- **Epic:** C · **Owner:** Vova / the group · **Day:** D1 · **Repo:** —

## Impact
Dan owns search and was **absent** from the 2026-06-02 meeting. The multibrand requirements
(PN collisions, brand attribution, config-number entry points) are new and materially change
search behavior. He must be briefed before release so C1/C2 findings have an owner and the
data-pipeline questions get answered fast.

## Action (async-friendly — don't block on a live meeting)
Post a short written brief in the green-team channel covering:
1. **What changed:** search now spans Ferris/Ventrac/McHale/Marcrest, not NH-only.
2. **The collision risk:** the same PN can exist across brands → results must carry correct
   `manufacturer_codes` / brand labels (C1).
3. **Config numbers:** Ferris 59-series numbers are a primary lookup entry point (A3).
4. **Open question for Dan:** are non-NH parts in PG `parts` fully populated with brand codes,
   or is there a data-pipeline gap (OBJ-02)? This determines whether C1 is a code fix or a
   data task.
5. Link this plan folder + [EPIC-C](../epics/EPIC-C-multibrand-search.md).

## Done when
- Dan has acknowledged the brief
- Any data-pipeline gap Dan flags is captured as one issue (impact statement, assigned
  Vova/Alex, label `goal/obj-02`/`goal/obj-04`) — not blocking V2
