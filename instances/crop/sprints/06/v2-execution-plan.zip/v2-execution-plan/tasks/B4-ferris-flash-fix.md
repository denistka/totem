# B4 — Ferris commercial-mower selection flash fix

- **Epic:** B · **Owner:** Oleg · **Day:** D3 · **Repo:** CROP-front
- **Branch:** `fix/ct-<issue>-ferris-flash` (cut from `origin/dev`)
- **Depends on:** A2 + A3 (Ferris routes clean) — so the flash isn't masked by a 404/empty grid

## Impact
John selected a Ferris commercial-mower config and saw a visual flash before the page
settled. This happens in the Friday ownership demo. One visible glitch on the flagship new
brand is enough to lose confidence in the whole platform.

## Reproduce
1. dev `/parts-diagrams/ferris` → Commercial Mowers group
2. Click a 59-series config card
3. Observe the flash before the assembly list settles

## Diagnose before coding
Chrome DevTools → Performance → record the click. Identify *what* flashes (whole page /
section / late image / text shift).

| Symptom | Likely cause | Fix |
|---|---|---|
| Whole page flashes white | `loading.tsx` fallback before data | Skeleton matching page dimensions |
| Section disappears/reappears | `useEffect` toggling visibility on mount | Remove effect / correct initial state |
| Image pops in after layout | no `priority` on above-fold image (LCP shift) | `priority` |
| Text shifts | font FOUT / SSR-client className mismatch | fix `className` parity |

## Check these (verified to exist)
- `app/parts-diagrams/loading.tsx` — skeleton vs real model-list layout match?
- `app/parts-diagrams/[brand]/page.tsx` — Suspense fallback?
- `app/parts-diagrams/[brand]/_components/brand-model-groups.tsx` — state changing on mount?
- (Note the repo also has `app/equipment/[slug]/parts-diagrams/loading.tsx` — confirm which surface the click actually uses.)

Fix should be ≤ ~20 lines. No `React.memo`/unjustified memo hooks (React Compiler handles it).

## Verify
- Ferris → Commercial Mowers → 59-series model → **no visible flash** (CLS ≈ 0 in Lighthouse)
- Same at 375px on Slow 4G throttle
- Existing Playwright/unit tests don't regress
