# A2 — Activate Marcrest in CROP-front (+ invariant tests)

- **Epic:** A · **Owner:** Oleg · **Day:** D1–D2 · **Repo:** CROP-front
- **Branch:** `feat/ct-<issue>-marcrest-activation` (cut from `origin/dev`)
- **Depends on:** A1 (hono registry), A5 (DB vocab row) — can start FE in parallel, verify after

## Impact
Marcrest has no live entry in `MANUFACTURER_CONFIGS`, and its registry record is pinned
`available: false`. Both `/parts/brand/marcrest` and `/parts-diagrams/marcrest` 404.
Activating it wires Marcrest into every CROP-front brand surface (brand hub, parts-diagrams,
equipment-types API, brands list, sitemap) at once.

## ⚠️ This is NOT a one-file change — read the findings first
The source docs say "copy the McHale pattern, `carriedIdentity` auto-sets available:true".
**False.** See [F2](../CODE-FINDINGS.md#f2) + [F3](../CODE-FINDINGS.md#f3). Four files:

### 1. `lib/equipment/brand-registry.ts` (L149-166) — flip the gate
Change the pinned record:
```ts
marcrest: {
  ...
  available: true,    // was: false  — activates the carried gate
  seoIndexed: false,  // unchanged — noindex until John approves
  ...
}
```
`carriedIdentity("marcrest")` reads `record.available`, so this flip is what actually makes
the brand navigable.

### 2. `lib/db/manufacturer-config.ts` — add the config entry
Copy the `mchale` block (L76-85). Marcrest has no search MV, so the Mongo field mapping is
the standard placeholder:
```ts
marcrest: {
  ...carriedIdentity("marcrest"),
  collectionName: "MARCREST",
  fields: {
    partNumber: ["Part Number"],
    description: ["Description"],
    price: ["List Price"],
  },
},
```

### 3. `lib/db/manufacturer-config.test.ts` — update invariants (else PR fails)
- L80 `AVAILABLE_SLUGS` → add `"marcrest"`
- L81 `AVAILABLE_CODES` → add `"MAR"`
- L178-184 carried-config `.each([...])` list → add `"marcrest"`
- (L98-106 "flags only activated" passes automatically once marcrest is `available:true`)

### 4. `lib/equipment/brand-registry.test.ts` — update the snapshot + parity block
- L84-93 `EXPECTED` marcrest entry → `available: true`
- L191-214 **"Marcrest parity"** describe block asserts `available:false` and
  `carriedSlugs NOT contain marcrest` — rewrite for the activated state (now carried).
- L97-101 "exactly the five carried catalog brands" still holds (count unchanged).

## Verify
- `bun run type-check` passes
- `bun test lib/db/manufacturer-config.test.ts lib/equipment/brand-registry.test.ts` — green
- `bun run dev`: `/parts/brand/marcrest` → **200** (content or graceful empty-state — not 404/500)
- `/parts-diagrams/marcrest` → **200**
- DevTools → Elements → `<meta name="robots">` on `/parts/brand/marcrest` → `noindex,follow`

## Guardrails
- **Never set `seoIndexed: true`** for Marcrest without John's explicit approval.
- Canonical slug lowercase, no spaces. No hardcoded hex (Moby DS tokens only).
