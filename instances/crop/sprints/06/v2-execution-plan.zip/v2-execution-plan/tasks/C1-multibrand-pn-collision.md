# C1 — Multibrand part-number collision audit

- **Epic:** C · **Owner:** Daniil · **Day:** D2–D3 · **Repo:** CROP-search-hono
- **Branch:** `fix/ct-<issue>-multibrand-pn` (cut from `origin/dev`)
- **Depends on:** A1

## Impact
With 4 brands live, the same part number can exist for both Ferris and New Holland. If
search returns only the NH result, or shows a Ferris result with no brand label, customers
order the wrong part. John: *"a part number can be the same for two brands potentially…
search is going to be much more complicated."*

## Steps

**1. Verify `manufacturer_codes` in search results.** Ask Vova for a test PN present in NH
**and** one new brand. `GET /api/search?q={testPN}` → each result's `manufacturer_codes`
array should carry the correct brand code(s).

**2. Verify brand facets.** `GET /api/filters` with `MANUFACTURER_FILTER_ENABLED=true` →
Ferris/Ventrac/McHale present in the brand facet list.

**3. Spot-check `src/lib/brand-extractor.ts`.** It guards CNH-family AI-copy contamination.
Ferris/Ventrac/McHale are **not** CNH family → must pass through `isAiBrandSafe` as safe:
```ts
isAiBrandSafe("Ferris commercial mower fuel filter", ["FRR"]) === true
```
(FRR is not in `BRAND_KEYWORDS`; just confirm it isn't accidentally blocked. **Do not widen
this file's scope** — CNH family only, per VOA review checklist.)

**4. Fix or document.**
- Code-side wrong `manufacturer_codes` → fix in `src/adapters/search-adapter.ts` or
  `src/routes/search.ts` (typically ≤ 20 lines).
- **Data gap** (non-NH parts missing brand codes in PG `parts`) → open **one** issue with
  impact statement, assign Vova/Alex. **Do not block V2** for a data issue.

## Verify
- No 500s on `/api/search` for Ferris part numbers
- PN that exists in 2+ brands → results attributed to the correct brand(s)
- Ferris facet visible in `/api/filters`

## ⚠️ Doc correction
Use **`FRR`** for Ferris in any test/assertion, not `FER` ([F1](../CODE-FINDINGS.md#f1)).
