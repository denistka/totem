# A6 — Ferris 59-series slug data fix (if needed) + cache refresh

- **Epic:** A · **Owner:** Vova · **Day:** D2–D3 · **Target:** Cloud SQL (`cnh_crop`)
- **Depends on:** A3 investigation result (only run if Daniil finds empty slugs)

## Impact
If Ferris 59-series models have empty `models.slug`, hono's brand-hub skips them and they
never appear in the model grid — the Ferris customer's primary lookup path silently fails.

## Steps

**1. Verify affected rows (always check before writing):**
```sql
SELECT model_code, model_number, slug
FROM models
WHERE product_line = 'FERRIS' AND model_number LIKE '59%'
  AND (slug IS NULL OR slug = '')
LIMIT 20;
```

**2. If rows exist, generate slugs from model_number:**
```sql
UPDATE models
SET slug = LOWER(REGEXP_REPLACE(model_number, '[^a-zA-Z0-9]+', '-', 'g'))
WHERE product_line = 'FERRIS' AND model_number LIKE '59%'
  AND (slug IS NULL OR slug = '');
```
- Confirm no slug collisions with existing Ferris rows before/after (the FE links by slug).

**3. Refresh the vocabulary cache:**
```bash
curl -X POST https://{hono-dev-url}/admin/cache/refresh -H "Authorization: Bearer ${ADMIN_REFRESH_TOKEN}"
```

**4. Notify Daniil** to re-run A3 acceptance (≥5 models, slug → assembly list, no 404).

## Verify
- Re-run the step-1 query → 0 empty-slug 59-series rows
- `GET /api/brand/ferris/models` now lists the 59-series models with slugs
