# D0 — Production deploy + demo readiness

- **Epic:** — (release) · **Owner:** Vova · **Day:** D4 (Sat 06-06, or the agreed demo day)
- **Depends on:** A4 smoke fully ✓ on `crop-dev.app`; all PRs merged to `dev`

## Impact
The cutover that puts 4 brands in front of ownership. Everything upstream exists to make
this step boring.

## Preconditions (all must be true)
- [ ] A4 4-brand smoke fully ✓ on `crop-dev.app`
- [ ] B5 navigation smoke ✓ (desktop loop + mobile drawer)
- [ ] All V2 PRs reviewed by Vova + merged to `dev`
- [ ] No open `priority: high` V2 bug from the smoke runs

## Steps
1. Confirm with John: "V2 smoke passed — deploying to prod. 4 brands: Ferris, Ventrac,
   McHale, Marcrest."
2. Tag the release: `git tag v2.0.0-brands && git push origin v2.0.0-brands`
3. Deploy `dev` → prod (front: Vercel; hono: Cloud Run pipeline).
4. Spot-verify each brand on `crop.clintontractor.net`:
   - `/parts/brand/ferris` → 200, content visible
   - `/parts/brand/ventrac` → 200
   - `/parts/brand/mchale` → 200
   - `/parts/brand/marcrest` → 200 (content or graceful empty-state)
5. Confirm `<meta name="robots">` = `noindex,follow` on the 4 new brand pages (none
   `seoIndexed` — no accidental indexing flip).
6. Confirm to John: ready for ownership demo.

## Rollback
If a brand page regresses in prod, revert the `dev`→prod deploy (Vercel: promote previous;
Cloud Run: route traffic to the prior revision) and re-open the smoke gate. Prefer rollback
over hot-fixing during the demo window.
