# B1 — Desktop circular navigation loop fix

- **Epic:** B · **Owner:** Oleg · **Day:** D1–D2 · **Repo:** CROP-front
- **Branch:** `fix/ct-<issue>-desktop-nav-loop` (cut from `origin/dev`)
- **Depends on:** —

## Impact
John demonstrated: clicking "Open parts diagram" from the assembly list sent the user back
to the same menu. This is the #1 navigation pain point — users who know their machine can't
reach their diagram in a straight line. Must be fixed before the demo.

## ⚠️ Start with live reproduction — the doc's named fix is already correct
The source docs say to fix `features/assemblies/brand-breadcrumb.tsx`. That file is
**purely presentational**, and the brand-routes assembly page **already** builds the brand
crumb correctly (`app/parts-diagrams/[brand]/assemblies/[assemblyCode]/page.tsx:117` →
`/parts-diagrams/${config.slug}`). See [F6](../CODE-FINDINGS.md#f6). **Do not "fix" the
already-correct crumb** — reproduce the real loop first.

## Reproduce (record the exact offending click)
Two diagram surfaces exist; check the one the brand actually uses
([routing reality](../CODE-FINDINGS.md#routing-reality-context-for-b1b2a4)):
1. `/parts/brand/ferris` (landing) — click "Open parts diagram" / schematic CTA. Where does it land?
2. `/parts-diagrams/ferris` → model → assembly → click every breadcrumb + any "back" link.
3. Also check the older `/equipment/[slug]/parts-diagrams/...` surface
   (`features/assemblies/assembly-view.tsx`, `features/diagrams/mobile-diagram-view.tsx`).

## Likely culprits (diagnose in order)
- The brand-landing "Open parts diagram" CTA target (`/parts/brand/[slug]` page + the
  schematic banner CTA `features/navigation/schematic-banner-cta/`). Note `isBannerRoute`
  renders the banner on `/parts/brand/`, `/parts`, `/brands`, `/equipment`,
  `/equipment/.../parts-diagrams` — **not** on `/parts-diagrams/[brand]/*`. If its href is
  `/parts-diagrams` root while the user is already inside a brand, that reads as a loop.
- A "back"/up link in `app/parts-diagrams/[brand]/_components/brand-assembly-list.tsx` or
  `brand-assembly-view.tsx` using a hardcoded path instead of `brandSlug`.
- The equipment-routes breadcrumb builder (older system).

## Fix
Point the offending link to the brand-specific path (`/parts-diagrams/{brandSlug}` or the
model page), or hide the banner CTA when already on a brand-diagram surface. Keep the change
small (≤ ~30 lines); QA prefers revert over fix-forward on regressions (>2 min).

## Tests
Add a unit test asserting the offending builder/component produces the brand-specific href
(e.g. extend `features/assemblies/brand-breadcrumb.test.tsx` or the banner-routes test, at
the real fix site).

## Verify (walk the full path in dev, 1280px)
- `/parts-diagrams/ferris` → model → assembly → "Ferris" crumb → lands `/parts-diagrams/ferris`
- No single click returns you to the page you were already on
- Repeat for Ventrac + McHale; New Holland path unchanged
