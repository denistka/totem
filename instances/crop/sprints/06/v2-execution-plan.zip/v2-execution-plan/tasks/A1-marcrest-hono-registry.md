# A1 — Marcrest (MAR) → hono BRAND_REGISTRY + carried-whitelist hardening

- **Epic:** A · **Owner:** Daniil · **Day:** D1 (Wed 06-03) · **Repo:** CROP-search-hono
- **Branch:** `feat/ct-<issue>-marcrest-registry` (cut from `origin/dev`)
- **Depends on:** — (this is the Day-1 unblocker for A2/A3/C1/C2)
- **Priority:** HIGHEST — everything in Track A/C is blocked until this lands

## Impact
Marcrest is the last of the 4 V2 brands. Without it every `/api/brand/marcrest/*` route
404s and the brand landing + diagrams are dead. ~30 min of work that unblocks Oleg (A2),
Daniil's own search tasks, and Vova's DB check simultaneously.

## File
`src/lib/vocabulary-cache.ts`

## Steps

**1. Add Marcrest to `BRAND_REGISTRY`** (after the `MCH` entry, ~L151):
```ts
{
  code: "MAR",
  canonicalName: "Marcrest",
  vocabulary: ["Marcrest", "MARCREST"],
  productLines: ["MARCREST"],
  querySynonyms: ["marcrest", "mar", "bale barron"],
},
```
- `productLines` UPPERCASE (matches `models.product_line`); `querySynonyms` lowercase.
- Copy the shape of the existing `VNT`/`FRR` entries.

**2. Harden `STATIC_CARRIED_WHITELIST`** (L213-224). ⚠️ See [F4](../CODE-FINDINGS.md#f4):
the whitelist currently has **none** of the non-CNH carried brands. Add all four so a
cold instance (before PG `brand_vocabulary` loads) still serves them:
```ts
const STATIC_CARRIED_WHITELIST: ReadonlySet<string> = new Set([
  "NHL", "FRD", "CIH", "FIA", "VRS", "FDB", "GEH", "HES", "LAV", "CTY",
  "VNT", "FRR", "MCH", "MAR", // non-CNH carried brands — cold-start parity with brand_vocabulary
]);
```

**3. Add unit tests** in `tests/vocabulary.test.ts` (patterns already there for FRR/VNT/MCH):
```ts
expect(normaliseManufacturerToken("marcrest")).toBe("MAR");
expect(brandNameToCode("Marcrest")).toBe("MAR");
expect(getBrandDisplayName("MAR")).toBe("Marcrest");
expect(getCarriedBrandCodes().has("MAR")).toBe(true);
```

## Verify
- `bun run test` — all pass · `bun run typecheck` — passes · `bun run lint`
- After cache refresh: `GET /api/brand/marcrest/models` → **200** (data) or clean
  **404 `{code:"NOT_FOUND"}`** if no Marcrest rows yet — must **not** be 500.

## Out of scope
DB schema, Marcrest data ingestion (Alex/Vova), `brand_vocabulary.is_carried` flip (A5).

## ⚠️ Doc correction
Ignore `FER` in the source docs — Ferris is **`FRR`** ([F1](../CODE-FINDINGS.md#f1)). The
"VNT/FER/MCH already in whitelist" claim is wrong — they are absent ([F4](../CODE-FINDINGS.md#f4)).
