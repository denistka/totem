# A3 — Ferris 59-config codes resolve to assemblies

- **Epic:** A · **Owner:** Daniil · **Day:** D2 · **Repo:** CROP-search-hono (+ DB hand-off to A6)
- **Branch:** `feat/ct-<issue>-ferris-59-routing` (cut from `origin/dev`)
- **Depends on:** A1

## Impact
Ferris commercial mowers are identified by "59-series" config numbers (e.g. 590xx) — the
customer's primary lookup path. John: *"if a customer knows that 59 number, that's how
they're going to find their diagram."* If a 59-number doesn't reach the right diagram, the
flagship Ferris use case is broken in the demo.

## Steps

**1. Are 59-series models in the vocabulary cache?**
After `POST /admin/cache/refresh` on dev hono, call `GET /api/brand/ferris/models`. In the
Commercial Mowers group, do 59-series `modelNumber` values appear?

**2. Are slugs populated?** `brand-hub.ts` skips models with empty slug
(`vocabulary-cache.ts` exposes `hasSlugForModelCode`; brand-hub guards on it). If 59-series
models are missing from the grid, the cause is empty `models.slug`. Confirm in DB:
```sql
SELECT model_code, model_number, slug
FROM models
WHERE product_line = 'FERRIS' AND model_number LIKE '59%'
LIMIT 10;
```
- **Empty slugs → data task.** Hand the exact `model_code` list + SQL to Vova ([A6](./A6-ferris-slug-data-fix.md)). Do not block; this is not a code bug.

**3. Does the model route resolve by slug?** Pick a populated 59-series slug from
`GET /api/brand/ferris/models`, then hit `/parts-diagrams/ferris/{slug}` in dev FE → assembly
list must render. Models routes accept **UUID or slug** via `src/lib/resolve-model-param.ts`
(per hono CLAUDE.md). If slug-form 404s, verify `resolve-model-param.ts` accepts slugs and
that `slugToModelCode` is populated for Ferris (`getModelCodeBySlug`).

## Verify
- ≥5 Ferris 59-series models present in `GET /api/brand/ferris/models`
- Navigating to their slug → assembly list (no 404)
- If blocked on data, A6 SQL handed to Vova with model_codes

## ⚠️ Doc correction
Ferris brand code is **`FRR`** ([F1](../CODE-FINDINGS.md#f1)) — relevant if you touch
display-name or carried-gate logic for Ferris.
