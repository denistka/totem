# C2 — Search brand context + facets + MAR display tests

- **Epic:** C · **Owner:** Daniil · **Day:** D2 · **Repo:** CROP-search-hono
- **Branch:** `feat/ct-<issue>-search-brand-context` (cut from `origin/dev`)
- **Depends on:** A1

## Impact
Search results and facets must carry correct brand labels for the 4 new brands so customers
can disambiguate. A brand returning `"UNK"` or a bare code in the UI looks broken.

## Steps

**1. Brand-label coverage tests** in `tests/vocabulary.test.ts`. FRR/VNT/MCH are already
covered (L50-53, 112-115) — add the **MAR** assertions A1 introduced and confirm none return
`"UNK"`/code:
```ts
expect(getBrandDisplayName("FRR")).toBe("Ferris");
expect(getBrandDisplayName("VNT")).toBe("Ventrac");
expect(getBrandDisplayName("MCH")).toBe("McHale");
expect(getBrandDisplayName("MAR")).toBe("Marcrest");
```

**2. Facet population.** Confirm `/api/filters` (with `MANUFACTURER_FILTER_ENABLED=true`)
surfaces Ferris/Ventrac/McHale/Marcrest facets, gated correctly by `getCarriedBrandCodes()`.

**3. Brand context on results.** Confirm search/autocomplete results for the new brands
carry a usable brand label (the FE reads `manufacturer_codes` / brand fields). If a result
shows no brand for a new-brand part, trace `src/adapters/search-adapter.ts`.

## Verify
- `bun run test` + `bun run typecheck` green
- `getBrandDisplayName` returns correct names for FRR/VNT/MCH/MAR (never `"UNK"`)
- Facets present for the 4 brands in `/api/filters`

## Guardrail (VOA checklist)
- `getBrandDisplayName` must never return `"UNK"` for a registered brand.
- No changes to `brand-safety.ts` / `brand-extractor.ts` scope (CNH family only).
