# A5 — Marcrest `brand_vocabulary` DB row + data check

- **Epic:** A · **Owner:** Vova · **Day:** D1 (parallel with A1) · **Target:** Cloud SQL (`cnh_crop`)

## Impact
`brand_vocabulary.is_carried` is hono's primary carried-brand source (`getCarriedBrandCodes()`
unions it with the static whitelist). With A1's whitelist hardening Marcrest is carried even
without a row, but the **display name** comes from this table first. Adding the row gives a
clean, DB-sourced identity and matches the other carried brands.

## Steps

**1. Upsert the carried-brand row:**
```sql
INSERT INTO brand_vocabulary (code, name, is_carried)
VALUES ('MAR', 'Marcrest', true)
ON CONFLICT (code) DO UPDATE SET is_carried = true, name = 'Marcrest';
```

**2. Confirm whether Marcrest catalog data exists:**
```sql
SELECT COUNT(*) AS n, product_line
FROM models
WHERE product_line ILIKE '%marcrest%' OR product_line ILIKE 'MAR%'
GROUP BY product_line;
```
- **0 rows → acceptable for V2.** Brand pages render the graceful empty-state
  ("Marcrest parts diagrams are not available yet"); the route does **not** 404/500.
  Tell Oleg + Denis so A2/A4 expect the empty-state rather than a model grid.

**3. While carried brands are loaded**, optionally confirm VNT/FRR/MCH rows are
`is_carried = true` (they back the live brands; the A1 whitelist is only the cold-start
fallback — see [F4](../CODE-FINDINGS.md#f4)).

**4. Trigger refresh** so hono picks up the row without a 60-min wait:
```bash
curl -X POST https://{hono-dev-url}/admin/cache/refresh -H "Authorization: Bearer ${ADMIN_REFRESH_TOKEN}"
```

## Verify
- `SELECT * FROM brand_vocabulary WHERE code='MAR';` → one row, `is_carried=true`
- Post-refresh `GET /api/brand/marcrest/models` consistent with data presence (200 or clean 404)
