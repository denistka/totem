# B3 — Equipment-type imagery: verify coverage + gap-fill

- **Epic:** B · **Owner:** Oleg · **Day:** D2 · **Repo:** CROP-front
- **Branch:** `feat/ct-<issue>-equipment-imagery-coverage` (cut from `origin/dev`)
- **Depends on:** —

## Impact
Brand pages should let users tell a "Mowers" card from a "Tractors" card by sight. John:
*"it's a little too much the same with just boxes."*

## ⚠️ This feature is already shipped — scope is verification, not a build
The source docs propose creating `lib/brand/equipment-type-images.ts`, adding an `imageUrl`
prop to `TypeCard`, and adding WebP assets. **All already exists** — see [F5](../CODE-FINDINGS.md#f5):
- `lib/equipment/type-image.ts` → `TYPE_IMAGE_MAP` + `getTypeImageSrc(slug)` (12 keys:
  tractors, tillage, loaders, commercial-mowers, harvesters, forage, construction, mowers,
  balers, hay-tools, planting, sprayers)
- `app/parts-diagrams/_components/type-card.tsx:55,70-87` already renders `<Image>` with a
  graceful Lucide-icon fallback for uncovered slugs
- `public/images/equipment-types/` already holds the 12 WebP assets
- `scripts/audit-equipment-type-images.ts` audits the asset set

## Real work — close the coverage gap for the 4 brands
1. **Get the live equipment-type slugs** each brand returns:
   `GET /api/brand/{ferris|ventrac|mchale|marcrest}/models` (or `/api/brand-taxonomy/{slug}`)
   → collect every `equipmentType.slug`.
2. **Diff against `TYPE_IMAGE_MAP` keys.** Any brand slug not in the map currently falls
   back to the generic icon (e.g. candidates like `utility-vehicles`, `attachments`,
   `snow`, `aerators` if present).
3. **For each gap:** add a ~400×250 transparent WebP to `public/images/equipment-types/`
   (sourced from Vova's Figma reference) **and** a key in `TYPE_IMAGE_MAP`. Run
   `bun scripts/audit-equipment-type-images.ts` to confirm the asset validates.
4. If an asset isn't available in time, leaving the icon fallback is acceptable — **no broken layout**.

## Rules
- Next.js `<Image>` only (already used); above-fold cards keep `priority`.
- No hardcoded hex — Moby DS tokens for any overlay/caption.

## Verify
- `/parts/brand/ferris` "Commercial Mowers" card shows the mower image (already works if slug = `commercial-mowers`)
- Each of the 4 brands: every TypeCard either shows an image or the icon fallback (never broken)
- `/parts/brand/new-holland` unchanged (no regression)
- `bun run type-check` + `bun scripts/audit-equipment-type-images.ts` pass
