# A4 — 4-brand end-to-end smoke test

- **Epic:** A · **Owner:** Denis (you) · **Day:** D3 (Fri 06-05) · **Repos:** both
- **Depends on:** A2 + A1 merged to `dev`; A5 (DB row) applied

## Impact
This is the gate before prod. If the smoke isn't run, V2 ships blind. The entire reason
QA sits in the loop is so bugs are found in dev, not after the ownership demo.

## Setup
Pull latest `dev` (both repos). Run hono dev (port 3001) + front dev (port 3000), or point
front at `crop-dev.app`. Test both viewports: **375px** and **1280px**.

## Per-brand checklist — `ferris` · `ventrac` · `mchale` · `marcrest`

**Brand landing `/parts/brand/{slug}`**
- [ ] Renders — no 404/500/blank white
- [ ] 375px: no overflow / cut-off · 1280px: layout intact
- [ ] Brand name in hero header
- [ ] ≥1 TypeCard (or graceful "coming soon" empty-state — not a broken grid)
- [ ] "Search all parts" CTA → `/parts?manufacturer=...`
- [ ] Serial-search widget visible
- [ ] No JS console errors
- [ ] `<meta name="robots">` → `noindex,follow` (not `nofollow`)

**Parts-diagrams `/parts-diagrams/{slug}`**
- [ ] Renders — no 404/500
- [ ] Model group grid (or graceful empty-state)
- [ ] ≥1 model card clickable

**Assembly (model → assembly)**
- [ ] Schematic/viewer image loads
- [ ] BOM table ≥1 part row
- [ ] "Add to cart" visible (or login prompt — not a JS error)

**Ferris-specific:** ≥3 commercial-mower 59-series models clickable → assembly loads (ties to A3/A6).

## On any ✗
Open one issue in the relevant repo. Body **starts with an impact statement**:
```
## Impact
<one paragraph: what breaks for the user, why it matters>
## Steps to reproduce
## Expected / Actual
```
Assign Oleg (FE) or Daniil (BE). Labels: `goal/obj-03`, priority `high`.
Record the result in this task and notify Vova — A4 fully ✓ is the precondition for D0 deploy.

## Note
Two diagram surfaces exist; new brands use the **brand-routes** path
(`/parts/brand → /parts-diagrams/[brand] → …`). See [routing reality](../CODE-FINDINGS.md#routing-reality-context-for-b1b2a4).
