# B2 — Mobile assembly view: expose diagram image-scroll panel

- **Epic:** B · **Owner:** Oleg · **Day:** D2–D3 · **Repo:** CROP-front
- **Branch:** `feat/ct-<issue>-mobile-diagram-parity` (cut from `origin/dev`)
- **Depends on:** —

## Impact
On desktop the assembly page shows a scrollable image strip so users visually browse diagram
sections ("I know it when I see it"). On mobile only a text chapter list exists. Most
customers browse on mobile — so the platform's strongest feature is invisible to the
majority. Closing the gap is core to Goal 2.

## Files (verified sizes)
- `features/assemblies/assembly-interactive-view.tsx` (70 lines) — holds the image-scroll
  panel. Check whether it's hidden via CSS breakpoint (`hidden md:flex`) or JS state.
- `features/assemblies/chapter-sidebar.tsx` (258 lines) — contains `MobileChapterDrawer`
  (open/close already handled). Put the image-strip content inside it.
- `features/assemblies/chapter-assembly-list.tsx` — thumbnail rendering to reuse.

## Build
1. A **"Browse Diagrams"** trigger on the assembly page, **mobile-only** (`md:hidden`) —
   header button or sticky bottom button.
2. Tap → `MobileChapterDrawer` opens with diagram section thumbnails (same images as the
   desktop hover strip).
3. Tap thumbnail → drawer closes + schematic viewer scrolls/snaps to that section.
4. The desktop text-filter input must work inside the drawer with the mobile keyboard.

## Do NOT
- Create a new drawer — reuse `MobileChapterDrawer`.
- Change the desktop layout.
- Break `use-zoom-pan.ts` touch gestures — **test pinch-zoom after the change**.

## Verify (375px / iPhone SE)
- "Browse Diagrams" button visible on the assembly page without scrolling
- Tap → drawer shows **images** (not just text)
- Tap image → viewer shows that section; drawer closed
- Tap outside → closes; schematic still pannable (no frozen viewport)
- Existing `features/assemblies/*.test.tsx` (incl. `assembly-interactive-view.scroll-wiring.test.tsx`)
  still pass; touch targets ≥ 44px
