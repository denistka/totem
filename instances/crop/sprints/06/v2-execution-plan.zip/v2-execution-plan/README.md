# CROP V2 — One-Week Execution Plan (S06)

> Day-by-day, role-by-role delivery plan for the V2 multi-brand launch.
> Built from `v2-docs/` + the S06 `.ptl`/`.pd` set, then **re-grounded against the
> actual code in `CROP-front`, `CROP-search-hono`** on 2026-06-03.
>
> Read [CODE-FINDINGS.md](./CODE-FINDINGS.md) first — the live code differs from the
> source docs in five material ways that change task scope and ownership.

---

## Goal (one line)

Ship a production-ready multi-brand parts platform — **Ferris, Ventrac, McHale, Marcrest**
live, reliable navigation to diagrams on desktop + mobile, correct multibrand search —
demoed to ownership at end of week.

---

## Calendar

| Day | Date | Weekday | Theme |
|-----|------|---------|-------|
| D1 | 2026-06-03 | **Wed** (today) | Unblock: Marcrest backend + FE activation start; nav loop repro; Dan briefed |
| D2 | 2026-06-04 | **Thu** | Build: mobile parity, search audit, Ferris 59-config, imagery gap-fill |
| D3 | 2026-06-05 | **Fri** | Stabilize: flash fix, full QA smoke, all PRs merged to `dev` |
| D4 | 2026-06-06 | **Sat** | Deploy + demo: prod cutover, 4-brand prod spot-check |

> **Calendar note.** The source docs call 06-06 "Friday" and 06-03 "Tuesday". By the
> calendar, 06-03 is a Wednesday and 06-06 is a Saturday. This plan uses real weekdays.
> **Reconcile the actual demo date with John** — if the demo is the real Friday it is
> 2026-06-05 (D3) and Saturday is not a work day; the plan front-loads so all engineering
> lands by **end of D3 (Fri 06-05)** and D4 is deploy/buffer only.

---

## Roles

| Person | Lane | Repo(s) | Output |
|--------|------|---------|--------|
| **Oleg** | Frontend / UX lead | CROP-front | Feature PRs (brand activation FE, nav, mobile, imagery, flash) |
| **Daniil** | Backend / Search | CROP-search-hono | Registry, search audit, Ferris config routing |
| **Denis** (you) | QA gate | both | Local PR runs, 4-brand smoke, bugs filed with impact statements |
| **Vova** | Lead / Data / Deploy | DB + both | DB rows, final PR review, prod deploy |
| **Dan** | Search specialist | CROP-search-hono | Briefed D1 on multibrand requirements; consulted on C1/C2 |

---

## PR workflow (agreed 2026-06-02)

```
Oleg/Daniil open PR  (branch cut from dev)
  → Denis runs locally + verifies acceptance criteria  ("Local test: PASS/FAIL")
    → Vova final UI/UX + code review
      → Vova merges to dev → deploy crop-dev.app → smoke → prod
```

- Branches **cut from `dev`**, PRs target `dev` (not `main`). See branch-state warning below.
- Every issue/PR opens with a **one-paragraph impact statement** (why, not what).
- Small bugs found in-scope: **fix inline + note in PR body**. Do not open new issues
  (issue-sprawl rule). Net-new work → one issue with impact statement at top.

### Branch-state warning (verified 2026-06-03)
- `CROP-front` is currently on `feat/s04-a3-loading-skeletons`, **not `dev`**. Every V2
  branch must be cut fresh from `origin/dev` — do **not** branch off the current HEAD.
- `CROP-search-hono` is on `main` (behind 7). Cut V2 branches from `origin/dev`.
- `CROP-parts-services` has unrelated uncommitted delivery-service work — **out of V2 scope**, leave untouched.

---

## Epics

| Epic | Title | Goals | Owner(s) | File |
|------|-------|-------|----------|------|
| **A** | Brand Activation | G1 | Daniil, Oleg, Vova | [epics/EPIC-A-brand-activation.md](./epics/EPIC-A-brand-activation.md) |
| **B** | Navigation & UX | G2, G4 | Oleg | [epics/EPIC-B-navigation-ux.md](./epics/EPIC-B-navigation-ux.md) |
| **C** | Multibrand Search | G3 | Daniil, Dan | [epics/EPIC-C-multibrand-search.md](./epics/EPIC-C-multibrand-search.md) |

Cross-cutting (G5 quality, G6 issue hygiene) is the PR workflow + smoke gates above,
enforced on every task.

---

## Task index

| Task | Epic | Owner | Day(s) | Repo | Depends on | File |
|------|------|-------|--------|------|-----------|------|
| A1 | A | Daniil | D1 | search-hono | — | [tasks/A1-marcrest-hono-registry.md](./tasks/A1-marcrest-hono-registry.md) |
| A2 | A | Oleg | D1–D2 | front | A1, A5 | [tasks/A2-marcrest-front-activation.md](./tasks/A2-marcrest-front-activation.md) |
| A3 | A | Daniil | D2 | search-hono | A1 | [tasks/A3-ferris-59-config-routing.md](./tasks/A3-ferris-59-config-routing.md) |
| A4 | A | Denis | D3 | both | A2, A1 merged | [tasks/A4-4brand-e2e-smoke.md](./tasks/A4-4brand-e2e-smoke.md) |
| A5 | A | Vova | D1 | DB | — | [tasks/A5-marcrest-db-vocab-row.md](./tasks/A5-marcrest-db-vocab-row.md) |
| A6 | A | Vova | D2–D3 | DB | A3 | [tasks/A6-ferris-slug-data-fix.md](./tasks/A6-ferris-slug-data-fix.md) |
| B1 | B | Oleg | D1–D2 | front | — | [tasks/B1-desktop-nav-loop-fix.md](./tasks/B1-desktop-nav-loop-fix.md) |
| B2 | B | Oleg | D2–D3 | front | — | [tasks/B2-mobile-diagram-parity.md](./tasks/B2-mobile-diagram-parity.md) |
| B3 | B | Oleg | D2 | front | — | [tasks/B3-equipment-imagery-verify.md](./tasks/B3-equipment-imagery-verify.md) |
| B4 | B | Oleg | D3 | front | A2, A3 | [tasks/B4-ferris-flash-fix.md](./tasks/B4-ferris-flash-fix.md) |
| B5 | B | Denis | D3 | front | B1, B2 PRs | [tasks/B5-navigation-smoke.md](./tasks/B5-navigation-smoke.md) |
| C1 | C | Daniil | D2–D3 | search-hono | A1 | [tasks/C1-multibrand-pn-collision.md](./tasks/C1-multibrand-pn-collision.md) |
| C2 | C | Daniil | D2 | search-hono | A1 | [tasks/C2-search-brand-context.md](./tasks/C2-search-brand-context.md) |
| C3 | C | Vova/group | D1 | — | — | [tasks/C3-brief-dan-search.md](./tasks/C3-brief-dan-search.md) |
| D0 | — | Vova | D4 | both | A4 green | [tasks/D0-production-deploy.md](./tasks/D0-production-deploy.md) |

---

## Dependency graph

```
A5 (MAR db row) ─┐
                 ├─→ A2 (MAR front activation) ─┐
A1 (MAR hono) ───┤                              ├─→ A4 (4-brand smoke) ─→ D0 (prod deploy)
                 ├─→ A3 (Ferris 59 routing) ─→ A6 (slug data fix) ─┘
                 ├─→ C1 (PN collision audit)
                 └─→ C2 (brand context + MAR tests)

B1 (desktop loop) ─┐
                   ├─→ B5 (nav smoke)
B2 (mobile parity)─┘
B3 (imagery verify) — independent
B4 (Ferris flash) — needs Ferris routes clean (A2/A3)
C3 (brief Dan) — D1, independent
```

**Critical path:** `A1 + A5 → A2 → A4 → D0`. Daniil's A1 and Vova's A5 are the
**Day-1 unblockers** — start both first thing.

---

## Day-by-day swimlanes

### D1 — Wed 2026-06-03 (unblock)
- **Daniil:** A1 — add `MAR` to hono registry + carried whitelist (+ harden VNT/FRR/MCH). Open PR by EOD.
- **Oleg:** B1 — reproduce the desktop nav loop live across **both** diagram systems; start A2 (flip `marcrest.available` in brand-registry, wire config + tests).
- **Vova:** A5 — confirm/insert `brand_vocabulary` MAR row; check `models` for Marcrest data. C3 — brief Dan on multibrand search.
- **Denis (you):** Set up both local dev envs; pull `dev`; prep the A4 smoke checklist; ready to run A1/A2 PRs the moment they open.

### D2 — Thu 2026-06-04 (build)
- **Daniil:** A3 — verify Ferris 59-config slug→assembly routing; C2 — brand context/facets + MAR display tests; start C1.
- **Oleg:** finish A2 (PR); B2 — mobile image-scroll drawer; B3 — verify equipment-type imagery coverage for the 4 brands, gap-fill.
- **Vova:** A6 — Ferris slug DB fix if A3 finds empty slugs + cache refresh; review incoming PRs after Denis passes them.
- **Denis:** run A1, A2, A3, C2 PRs locally; comment PASS/FAIL; file bugs with impact statements.

### D3 — Fri 2026-06-05 (stabilize) — **all engineering lands today**
- **Oleg:** B4 — Ferris commercial-mower flash fix; address smoke bugs.
- **Daniil:** finish C1; address smoke bugs.
- **Denis:** A4 — full 4-brand E2E smoke; B5 — navigation smoke (B1+B2 sign-off).
- **Vova:** final review + merge all green PRs to `dev`; deploy `dev` → `crop-dev.app`; coordinate smoke re-runs.

### D4 — Sat 2026-06-06 (deploy + demo)
- **Vova:** D0 — tag `v2.0.0-brands`, deploy `dev` → prod, spot-check 4 brand pages on `crop.clintontractor.net`, confirm to John.
- **Denis:** prod spot-check parity with dev smoke.

---

## Definition of Done (V2)

A brand is production-ready when **all** hold:
- [ ] `/parts/brand/{slug}` → 200, brand name + TypeCards visible
- [ ] `/parts-diagrams/{slug}` → 200, model grid visible (or graceful empty-state)
- [ ] ≥1 assembly diagram loads end-to-end (schematic + BOM row)
- [ ] No JS console errors at 375px and 1280px
- [ ] No circular nav loop; brand crumb → brand page (not diagrams root)
- [ ] Ferris: ≥3 commercial-mower 59-series models clickable + loading
- [ ] Multibrand PN search returns correctly attributed results
- [ ] Denis ran the smoke checklist — all ✓
- [ ] Vova reviewed + merged the PR
- [ ] Verified on `crop-dev.app` before prod

**Brand-page `seoIndexed` stays `false` for all four new brands** — never flip to `true`
without John's explicit approval.
