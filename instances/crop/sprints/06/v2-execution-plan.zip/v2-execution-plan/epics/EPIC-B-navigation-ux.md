# EPIC B — Navigation & UX

**Goals 2 + 4** · Owner: Oleg · Repo: CROP-front

## Outcome

Getting to a parts diagram is a straight line on both desktop and mobile, and brand pages
feel brand-specific rather than a wall of identical boxes.

- **Desktop:** no circular navigation loop — every breadcrumb/back link goes "up", never
  back to the page you were already on.
- **Mobile:** the diagram image-scroll experience (desktop-only today) is reachable on
  mobile via a trigger into the existing `MobileChapterDrawer`.
- **Brand pages:** equipment-type cards show type-specific imagery (already shipped —
  verify coverage for the 4 brands).
- **Ferris:** no visible flash when selecting a commercial-mower config.

## Why

John: *"Getting to that screen is the primary pain point."* The diagram screen itself is
strong; the path to it loses users — especially on mobile, where most customers browse.
And *"it's a little too much the same with just boxes"* — visual clarity drives conversion.

## State of play (verified 2026-06-03)

- The brand-routes assembly breadcrumb is **already correct** — the loop is elsewhere; B1
  starts with live repro. (see [F6](../CODE-FINDINGS.md#f6))
- Equipment-type imagery is **already built** (`lib/equipment/type-image.ts`, 12 assets,
  `TypeCard` renders it with icon fallback) — B3 is verify + gap-fill. (see [F5](../CODE-FINDINGS.md#f5))
- `MobileChapterDrawer` lives in `features/assemblies/chapter-sidebar.tsx` (258 lines);
  `assembly-interactive-view.tsx` (70 lines) holds the image panel. (B2)

## Tasks

| Task | Owner | Day | Notes |
|------|-------|-----|-------|
| [B1 — Desktop circular nav loop fix](../tasks/B1-desktop-nav-loop-fix.md) | Oleg | D1–D2 | Repro first; both diagram systems |
| [B2 — Mobile assembly image-scroll panel](../tasks/B2-mobile-diagram-parity.md) | Oleg | D2–D3 | Reuse `MobileChapterDrawer`; don't break pinch-zoom |
| [B3 — Equipment-type imagery: verify + gap-fill](../tasks/B3-equipment-imagery-verify.md) | Oleg | D2 | Already shipped; check 4-brand slug coverage |
| [B4 — Ferris commercial-mower flash fix](../tasks/B4-ferris-flash-fix.md) | Oleg | D3 | Needs clean Ferris routes (A2/A3) |
| [B5 — Navigation smoke (B1+B2 sign-off)](../tasks/B5-navigation-smoke.md) | Denis | D3 | Desktop loop + mobile drawer |

## Epic acceptance

- Desktop: from `/parts-diagrams/{brand}` → model → assembly, every link routes "up"; brand
  crumb → `/parts-diagrams/{brand}`; breadcrumb depth ≤ 4
- Mobile (375px): "Browse Diagrams" trigger visible on assembly page; opens drawer with
  image thumbnails; tap image → viewer scrolls to section; pinch-zoom still works
- `/parts/brand/{brand}` TypeCards show type imagery (not generic icon) for covered slugs;
  uncovered slugs fall back gracefully (no broken layout)
- Ferris commercial-mower selection: CLS ≈ 0, no visible flash at 375px + 1280px
- Touch targets ≥ 44px; no console errors at 375px/1280px
